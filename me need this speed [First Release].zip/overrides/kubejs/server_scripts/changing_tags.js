ServerEvents.tags('item', event => {
  event.add('farmersdelight:tools/knives', 'gtceu:crafting_tools/knife')
  //early ores and crafting tool
  event.add('minecraft:nuggets_for_tools', 'gtceu:copper_nugget')
  event.add('minecraft:nuggets_for_tools', 'gtceu:tin_nugget')
  event.add('minecraft:nuggets_for_tools', 'minecraft:iron_nugget',)
  event.add('minecraft:ingots_for_tools', 'kubejs:low_grade_iron_ingot')
  event.add('minecraft:ingots_for_tools', 'kubejs:poor_copper_ingot')
  event.add('minecraft:ingots_for_tools', 'kubejs:poor_tin_ingot')
  //iron pickaxes
  event.add('minecraft:iron_pickaxes', 'minecraft:iron_pickaxe')
  event.add('minecraft:iron_pickaxes', 'gtceu:iron_pickaxe')
  event.add('minecraft:iron_pickaxes', 'gtceu:wrought_iron_pickaxe')
  //diamond pickaxes
  event.add('minecraft:diamond_pickaxes', 'minecraft:diamond_pickaxe')
  event.add('minecraft:diamond_pickaxes', 'gtceu:diamond_pickaxe')
  event.removeAllTagsFrom('gtceu:zinc_ingot')
  event.removeAllTagsFrom('gtceu:zinc_block')
  event.removeAllTagsFrom('gtceu:zinc_nugget')
  event.removeAllTagsFrom('create:brass_ingot')
  event.removeAllTagsFrom('create:iron_sheet')
  event.add('minecraft:raw_iron', 'c:ingots/iron')
  event.add('gtceu:raw_magnetite', 'c:ingots/iron')
  event.add('gtceu:raw_yellow_limonite', 'c:ingots/iron')
  event.add('gtceu:raw_hematite', 'c:ingots/iron')
  event.removeAllTagsFrom('create:copper_sheet')
})

ServerEvents.tags('worldgen/biome', e => {
  e.removeAll('minecraft:has_structure/stronghold');
})