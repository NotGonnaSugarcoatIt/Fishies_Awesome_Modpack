LootJS.modifiers(event => {

    //Ore Blocks --> Ore Nuggets when using Flint Pickaxe

    event.addBlockModifier('#c:ores/iron')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('minecraft:raw_iron')
        .addLoot(LootEntry.of('minecraft:iron_nugget', 2)),
    event.addBlockModifier('#c:ores/hematite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_hematite')
        .addLoot(LootEntry.of('minecraft:iron_nugget', 2)),
    event.addBlockModifier('#c:ores/goethite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_goethite')
        .addLoot(LootEntry.of('minecraft:iron_nugget', 2)),
    event.addBlockModifier('#c:ores/yellow_limonite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_yellow_limonite')
        .addLoot(LootEntry.of('minecraft:iron_nugget', 2)),
    event.addBlockModifier('#c:ores/magnetite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_magnetite')
        .addLoot(LootEntry.of('minecraft:iron_nugget', 2)),
    event.addBlockModifier('#c:ores/tin')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_magnetite')
        .removeLoot('mekanism:raw_tin')
        .addLoot(LootEntry.of('gtceu:tin_nugget', 2)),
    event.addBlockModifier('#c:ores/cassiterite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_cassiterite')
        .addLoot(LootEntry.of('gtceu:tin_nugget', 2)),
    event.addBlockModifier('#c:ores/copper')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .removeLoot('gtceu:raw_copper')
        .addLoot(LootEntry.of('gtceu:copper_nugget', 2)),
    event.addBlockModifier('#c:ores/malachite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_malachite')
        .addLoot(LootEntry.of('gtceu:copper_nugget', 2)),
    event.addBlockModifier('#c:ores/chalcopyrite')
        .matchTool('gtceu:flint_pickaxe')
        .removeLoot('gtceu:raw_malachite')
        .addLoot(LootEntry.of('gtceu:copper_nugget', 2)),      
    //Common Blocks

    event.addBlockModifier('#minecraft:dirt')
        .randomChance(0.10)
        .addLoot(LootEntry.of('minecraft:flint')),
    event.addBlockModifier('minecraft:short_grass')
        .randomChance(0.05)
        .addLoot(LootEntry.of('minecraft:stick')),
    event.addBlockModifier('minecraft:tall_grass')
        .randomChance(0.05)
        .addLoot(LootEntry.of('minecraft:stick')),
    event.addBlockModifier('minecraft:fern')
        .randomChance(0.05)
        .addLoot(LootEntry.of('minecraft:stick')),
     event.addBlockModifier('minecraft:fern')
        .randomChance(0.05)
        .addLoot(LootEntry.of('minecraft:stick'))

    event.addEntityModifier('minecraft:wither_skeleton')
        .removeLoot('minecraft:wither_skeleton_skull')
        .randomChance(0.2)
        .addLoot('minecraft:wither_skeleton_skull')

})
