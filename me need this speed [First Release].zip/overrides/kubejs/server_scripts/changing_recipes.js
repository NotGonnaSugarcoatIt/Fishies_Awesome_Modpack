ServerEvents.recipes(event => {
  addCreateRecipeHandler(event)
  const gregtech = event.recipes.gtceu;

  //
  // FUNCTIONS LIBRARY
  //

  // removes ALL crafting table recipes
  function removeCrafting(input){ 
      event.remove({output: input, type:'minecraft:crafting_shaped'})       
      event.remove({output: input, type:'minecraft:crafting_shapeless'})
    }

  function chainArmor(output, input) {
      event.shaped(output, [
        'A A',
        'ABA',
        'A A'
      ], {
        A: 'minecraft:iron_ingot',
        B: input
      })
    }

  function ironArmor(output, input) {
      event.shaped(output, [
        ' A ',
        'ABA',
        ' A '
      ], {
        A: 'minecraft:iron_ingot',
        B: input
      })
    }

  function diamondArmor(output, input) {
      event.shaped(output, [
        ' A ',
        'ABA',
        ' A '
      ], {
        A: 'minecraft:diamond',
        B: input
      })
    }
 
  function logging(output, input) {
    event.shaped(output, [
      'A',
      'B'
    ], {
      A: '#minecraft:axes',
      B: input
    }).damageIngredient('#minecraft:axes')
  } 

  function slabbing(output, input) {
    event.shaped(output, [
      'AB'
    ], {
      A: '#minecraft:axes',
      B: input
    }).damageIngredient('#minecraft:axes')
  }
  

  //
  // GREGTECH MACHINE CRAFTING FUNCTIONS LIBRARY
  //

  //remember that fluidInput must be '#x fluid'
  function fluidSolidifier(idInput, fluidInput, castingMold, itemOutput, eut, duration){
    gregtech.fluid_solidifier(idInput)
        .inputFluids(fluidInput)
        .inputItems(castingMold).keepIngredient(castingMold)
        .outputItems(itemOutput)
        .EUt(eut)
        .duration(duration)
  }

  function compressing(idInput, itemInput, itemOutput, eut, duration){
      gregtech.compressor(idInput)
      .inputItems(itemInput)
      .outputItems(itemOutput)
      .EUt(eut)
      .duration(duration)
  }
  function alloySmelter(idInput, itemInput, castingMold, itemOutput, eut, duration){
      gregtech.alloy_smelter(idInput)
      .inputItems(itemInput)
      .inputItems(castingMold).keepIngredient(castingMold)
      .outputItems(itemOutput)
      .EUt(eut)
      .duration(duration)
  }

  function macerating(idInput, itemInput, itemOutput, eut, duration){
      gregtech.macerator(idInput)
      .inputItems(itemInput)
      .outputItems(itemOutput)
      .EUt(eut)
      .duration(duration)
  }

  function arcFurnace(idInput, fluidInput, itemInput, itemOutput, eut, duration){
    gregtech.arc_furnace(idInput)
        .inputFluids(fluidInput)
        .inputItems(itemInput)
        .outputItems(itemOutput)
        .EUt(eut)
        .duration(duration)
  }



  //
  // LOG NERF
  //

  event.remove({id: 'minecraft:oak_planks'})
  event.remove({id: 'minecraft:spruce_planks'})
  event.remove({id: 'minecraft:birch_planks'})
  event.remove({id: 'minecraft:jungle_planks'})
  event.remove({id: 'minecraft:acacia_planks'})
  event.remove({id: 'minecraft:dark_oak_planks'})
  event.remove({id: 'minecraft:crimson_planks'})
  event.remove({id: 'minecraft:warped_planks'})
  event.remove({id: 'minecraft:mangrove_planks'})
  event.remove({id: 'minecraft:bamboo_planks'})
  event.remove({id: 'minecraft:cherry_planks'})

  function logNerf(output, input) {
    event.shapeless(output, [
      input
    ])
  }
  logNerf('minecraft:stripped_oak_log', "minecraft:oak_log")
  logNerf('minecraft:stripped_spruce_log', "minecraft:spruce_log")
  logNerf('minecraft:stripped_birch_log', "minecraft:birch_log")
  logNerf('minecraft:stripped_jungle_log', "minecraft:jungle_log")
  logNerf('minecraft:stripped_acacia_log', "minecraft:acacia_log")
  logNerf('minecraft:stripped_dark_oak_log', "minecraft:dark_oak_log")
  logNerf('minecraft:stripped_crimson_stem', "minecraft:crimson_stem")
  logNerf('minecraft:stripped_warped_stem', "minecraft:warped_stem")
  logNerf('minecraft:stripped_mangrove_log', "minecraft:mangrove_log")
  logNerf('minecraft:stripped_bamboo_block', "minecraft:bamboo_block")
  logNerf('minecraft:stripped_cherry_log', "minecraft:cherry_log")
  
  //
  // FLINT TOOLS
  //

  event.remove({id: 'gtceu:flint_pickaxe'})
  event.shaped(
    Item.of('gtceu:flint_pickaxe', 1),
    [
      'CB',
      'BA'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint',
      C: '#minecraft:saplings'
    }
    )
  event.remove({output: 'gtceu:flint_knife'})
  event.remove({id: 'farmersdelight:flint_knife'})
  event.shaped(
    Item.of('farmersdelight:flint_knife', 1),
    [
      'BC',
      ' A'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint',
      C: '#minecraft:saplings'
    }
    )
    event.remove({output: 'gtceu:flint_axe'})
    event.shaped(
    Item.of('gtceu:flint_axe', 1),
    [
      'BC',
      'BA'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint',
      C: '#minecraft:saplings'
    }
    )
    event.remove({output: 'gtceu:flint_shovel'})
    event.shaped(
    Item.of('gtceu:flint_shovel', 1),
    [
      'CB',
      ' A'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint',
      C: '#minecraft:saplings'
    }
    )
    event.remove({output: 'gtceu:flint_sword'})
    event.shaped(
    Item.of('gtceu:flint_sword', 1),
    [
      'BB',
      'AB'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint'
    }
    )
    event.remove({output: 'gtceu:flint_hoe'})
    event.shaped(
    Item.of('gtceu:flint_hoe', 1),
    [
      'BB',
      'CA'
    ],
    {
      A: 'minecraft:stick',
      B: 'minecraft:flint',
      C: '#minecraft:saplings'
    }
    )
    
    //
    // ARMOR CHANGES
    //

  //Leather Armor
    event.remove({output: 'minecraft:leather_helmet'})
    event.shaped(Item.of('minecraft:leather_helmet', 1),
      ['AAA', 'ABA'],
      {A: 'minecraft:leather', B: 'kubejs:bone_needle_with_string'}
    ).keepIngredient('kubejs:bone_needle_with_string')

    event.remove({output: 'minecraft:leather_chestplate'})
    event.shaped(Item.of('minecraft:leather_chestplate', 1),
      ['ABA', 'AAA', 'AAA'],
      {A: 'minecraft:leather', B: 'kubejs:bone_needle_with_string'}
    ).keepIngredient('kubejs:bone_needle_with_string')

    event.remove({output: 'minecraft:leather_leggings'})
    event.shaped(Item.of('minecraft:leather_leggings', 1),
      ['AAA', 'ABA', 'A A'],
      {A: 'minecraft:leather', B: 'kubejs:bone_needle_with_string'}
    ).keepIngredient('kubejs:bone_needle_with_string')

    event.remove({output: 'minecraft:leather_boots'})
    event.shaped(Item.of('minecraft:leather_boots', 1),
      ['   ', 'ABA', 'A A'],
      {A: 'minecraft:leather', B: 'kubejs:bone_needle_with_string'}
    ).keepIngredient('kubejs:bone_needle_with_string')

    //Chainmail Armor

    event.remove({output: 'minecraft:chainmail_helmet'})
    event.remove({output: 'minecraft:chainmail_chestplate'})
    event.remove({output: 'minecraft:chainmail_leggings'})
    event.remove({output: 'minecraft:chainmail_boots'})
    chainArmor('minecraft:chainmail_helmet', 'minecraft:leather_helmet')
    chainArmor('minecraft:chainmail_chestplate', 'minecraft:leather_chestplate')
    chainArmor('minecraft:chainmail_leggings', 'minecraft:leather_leggings')
    chainArmor('minecraft:chainmail_boots', 'minecraft:leather_boots')

    //Iron Armor
 
    event.remove({output: 'minecraft:iron_helmet'})
    event.remove({output: 'minecraft:iron_chestplate'})
    event.remove({output: 'minecraft:iron_leggings'})
    event.remove({output: 'minecraft:iron_boots'})
    ironArmor('minecraft:iron_helmet', 'minecraft:chainmail_helmet')
    ironArmor('minecraft:iron_chestplate', 'minecraft:chainmail_chestplate')
    ironArmor('minecraft:iron_leggings', 'minecraft:chainmail_leggings')
    ironArmor('minecraft:iron_boots', 'minecraft:chainmail_boots')

    //Diamond Armor

    event.remove({output: 'minecraft:diamond_helmet'})
    event.remove({output: 'minecraft:diamond_chestplate'})
    event.remove({output: 'minecraft:diamond_leggings'})
    event.remove({output: 'minecraft:diamond_boots'})
    diamondArmor('minecraft:diamond_helmet', 'minecraft:iron_helmet')
    diamondArmor('minecraft:diamond_chestplate', 'minecraft:iron_chestplate')
    diamondArmor('minecraft:diamond_leggings', 'minecraft:iron_leggings')
    diamondArmor('minecraft:diamond_boots', 'minecraft:iron_boots')

    //
    // CHANGING MODDED ITEMS
    //

    event.replaceInput({input: 'create:electron_tube'}, 'create:electron_tube', 'gtceu:vacuum_tube')
    event.remove({output:'create:electron_tube'})

    removeCrafting('create:andesite_alloy')

    event.shaped(Item.of('create:andesite_alloy'), ['ABC','BA '],{A:'minecraft:iron_nugget',B:'minecraft:andesite',C:'#c:tools/hammer'})


    // Changing Zinc 
    event.replaceOutput({output: 'gtceu:zinc_ingot'}, 'gtceu:zinc_ingot', 'create:zinc_ingot')
    event.replaceOutput({output: 'gtceu:zinc_block'}, 'gtceu:zinc_block', 'create:zinc_block')
    event.replaceOutput({output: 'gtceu:zinc_nugget'}, 'gtceu:zinc_nugget', 'create:zinc_nugget')


    compressing('compress_zinc_nugget_to_ingot', '9x create:zinc_nugget', 'create:zinc_ingot', 2, 300)
    compressing('compress_zinc_to_block', '9x create:zinc_ingot', 'create:zinc_block', 2, 300)

    macerating('macerate_zinc_ingot', 'create:zinc_ingot', 'gtceu:zinc_dust', 2, 65)
    macerating('macerate_zinc_nugget', 'create:zinc_nugget', 'gtceu:tiny_zinc_dust', 2, 65)

    fluidSolidifier('solidify_zinc_to_ingot', '144x gtceu:zinc', 'gtceu:ingot_casting_mold', 'create:zinc_ingot', 7, 65)
    fluidSolidifier('solidify_zinc_to_nugget', '144x gtceu:zinc', 'gtceu:nugget_casting_mold', '9x create:zinc_nugget', 7, 65 )

    alloySmelter('alloy_smelt_zinc_nugget_to_ingot', '9x create:zinc_nugget', 'gtceu:ingot_casting_mold', 'create:zinc_ingot',7,65)
    alloySmelter('alloy_smelt_zinc_to_ingot', 'create:zinc_block', 'gtceu:nugget_casting_mold', '9x create:zinc_ingot',7,65)
    alloySmelter('alloy_smelt_zinc_to_nugget', 'create:zinc_ingot', 'gtceu:ingot_casting_mold', 'create:zinc_ingot',7,65)
    
    arcFurnace('arc_zinc_plate', '65x gtceu:oxygen','gtceu:zinc_plate', 'create:zinc_ingot', 30, 65)
    arcFurnace('arc_double_zinc_plate', '130x gtceu:oxygen','gtceu:double_zinc_plate', '2x create:zinc_ingot', 30, 130)
    arcFurnace('arc_zinc_dust', '65x gtceu:oxygen','gtceu:zinc_dust', 'create:zinc_ingot', 30, 65)
    arcFurnace('arc_zinc_block', '585x gtceu:oxygen','gtceu:zinc_block', '9x create:zinc_ingot', 30, 585)
    arcFurnace('arc_zinc_ring', '14x gtceu:oxygen','gtceu:zinc_ring', '2x create:zinc_nugget', 30, 14)
    arcFurnace('arc_zinc_rod', '28x gtceu:oxygen','gtceu:zinc_rod', '4x create:zinc_ingot', 30, 28)
    arcFurnace('arc_fine_zinc_wire', '7x gtceu:oxygen','gtceu:zinc_dust', 'create:zinc_nugget', 30, 7)
    arcFurnace('arc_zinc_foil', '14x gtceu:oxygen','gtceu:zinc_foil', '2x create:zinc_ingot', 30, 14)


      // Changing Brass
    event.replaceOutput({output: 'create:brass_ingot'}, 'create:brass_ingot', 'gtceu:brass_ingot')
    event.replaceInput({input: 'create:brass_ingot'}, 'create:brass_ingot', 'gtceu:brass_ingot')

    event.remove({output:'create:brass_ingot'})
    event.recipes.createMixing(
      'gtceu:brass_ingot', ['minecraft:copper_ingot', 'minecraft:copper_ingot', 'minecraft:copper_ingot', 'create:zinc_ingot',]
    ).heated(),

      // Iron Plates
    event.replaceOutput({output: 'create:iron_sheet'}, 'create:iron_sheet', 'gtceu:iron_plate')
    event.replaceInput({input: 'create:iron_sheet'}, 'create:iron_sheet', 'gtceu:iron_plate')
    event.remove({id:'create:pressing/iron_ingot'})
    event.recipes.createPressing(
      'gtceu:iron_plate', ['minecraft:iron_ingot']
    )
    
      //Glass Tubes
    event.shaped(Item.of('16x minecraft:glass_pane'), ['AAA','AAA'], {A:'minecraft:glass'})
    event.shaped(Item.of('gtceu:glass_tube'), ['AAA','AAA'], {A: 'minecraft:glass_pane'})
    
    // Rubber Sheet
    event.shaped(Item.of('gtceu:rubber_plate'),[' A ',' B ',' B '], {A: '#c:tools/hammer',B:'gtceu:sticky_resin'})

    // Copper Sheet
    event.remove({id:'create:pressing/copper_ingot'})
    event.recipes.createPressing(
      [
        'gtceu:copper_plate'
      ],
      'minecraft:copper_ingot'
    )

    event.recipes.createCompacting('3x gtceu:rubber_plate', ['gtceu:sticky_resin', 'gtceu:sticky_resin'])

    event.shaped(Item.of('2x gtceu:wood_plate'), ['AB'], {A: '#c:tools/saw', B:'#minecraft:wooden_slabs'})

    event.shapeless(Item.of('gtceu:red_alloy_dust'), ['8x minecraft:redstone','#c:dusts/copper'])
    event.blasting('gtceu:red_alloy_ingot', 'gtceu:red_alloy_dust')

    

    //
    // CHANGING CREATE MACHINES
    //

    event.remove({output:'create:water_wheel'})
    event.shaped(Item.of('create:water_wheel'), ['AAA','ABA','AAA'], {A:'gtceu:treated_wood_planks',B:'create:shaft'})

    event.remove({output:'create:large_water_wheel'})
    event.shaped(Item.of('create:large_water_wheel'), ['AAA','ABA','AAA'], {A:'gtceu:treated_wood_planks',B:'create:water_wheel'})

    event.remove({output:'create:depot'})
    event.shapeless(Item.of('create:depot'), ['gtceu:wrought_iron_plate', 'create:andesite_casing'])

    // Andesite Casing Machines

    event.remove({output:'create:mechanical_mixer'})
    event.shaped(Item.of('create:mechanical_mixer'), [' A ',' B ', ' C '], {A:'gtceu:steel_gear',B:'create:andesite_casing',C:'gtceu:steel_rotor'})
    
    event.remove({output:'create:mechanical_press'})
    event.shaped(Item.of('create:mechanical_press'), [' A ', ' B ', 'CCC'], {A:'create:shaft', B: 'create:andesite_casing', C:'gtceu:double_steel_plate'})

    event.remove({output:'create:mechanical_saw'})
    event.shaped(Item.of('create:mechanical_saw'), ['ABA',' C '], {A: 'create:cogwheel', B: 'gtceu:steel_buzz_saw_blade', C: 'create:andesite_casing'})

    event.remove({output:'create:millstone'})
    event.shaped(Item.of('create:millstone'), [' A ',' B ',' C '], {A: 'gtceu:small_steel_gear', B: 'create:andesite_casing', C: 'gtceu:double_iron_plate'})

    event.remove({output:'create:encased_fan'})
    event.shaped(Item.of('create:encased_fan'), [' A ', ' B ', ' C '], {A:'create:shaft', B: 'create:andesite_casing', C:'gtceu:steel_rotor'})

    event.remove({output:'create:mechanical_drill'})
    event.shaped(Item.of('create:mechanical_drill'), [' A ','ABA',' C '], {A:'minecraft:diamond',B:'gtceu:steel_ingot',C:'create:andesite_casing'})

    event.remove({output:'create:empty_blaze_burner'})
    event.shaped(Item.of('create:empty_blaze_burner'), [' A ','ABA',' A '], {A:'gtceu:steel_plate',B:'minecraft:netherrack'})

    event.remove({output:'create:basin'})
    event.shaped(Item.of('create:basin'), ['A A','AAA'], {A:'gtceu:wrought_iron_ingot'})


    //
    // UNCATEGORIZED
    //

  event.shaped(Item.of('minecraft:pointed_dripstone'), ['A A','AAA',' A '], {A: '#c:stones'})

  event.remove({id:'minecraft:ladder'})
  event.shaped(Item.of('6x minecraft:ladder'), ['A A','AAA','A A'], {A:'minecraft:stick'})

    event.shaped(Item.of('minecraft:crafting_table'), ['AAA','ABA','AAA'], {A:'#minecraft:planks',B:'#c:ingots'})

   event.recipes.createMixing(
        '3x gtceu:steel_ingot',
        [
            'minecraft:iron_ingot',
            'minecraft:iron_ingot',
            '#minecraft:coals',
        ],
    ).superheated();

    event.recipes.createSplashing(
      ['minecraft:tuff'],
      'minecraft:cobblestone'
    )

    event.recipes.createHaunting(
      ['minecraft:netherrack'],
      'minecraft:tuff'
    )

    event.recipes.createMilling(
      [
        'gtceu:quartz_sand_dust'
      ],
      'minecraft:sand'
    )

    event.recipes.createMilling(
      [
        'gtceu:flint_dust'
      ],
      'minecraft:flint'
    )

    event.smelting('minecraft:glass', 'gtceu:glass_dust')
    event.blasting('minecraft:glass', 'gtceu:glass_dust')
    event.smithing(
      'minecraft:elytra',
      'minecraft:netherite_upgrade_smithing_template',
      'hangglider:reinforced_hang_glider',
      'minecraft:netherite_ingot'
    )

    event.recipes.createHaunting(
      [
        'minecraft:slime_ball'
      ],
      'gtceu:sticky_resin'
    )

    event.remove({id:'minecraft:netherite_ingot'})
    event.shapeless(Item.of('kubejs:plated_gold_ingot'),
    ['minecraft:gold_ingot','minecraft:netherite_scrap'])
    event.smelting('minecraft:netherite_ingot', 'kubejs:plated_gold_ingot')
    event.blasting('minecraft:netherite_ingot', 'kubejs:plated_gold_ingot')

    event.shaped(Item.of('2x minecraft:nether_star'),
      ['ACA','CBC','ACA'],
    {A:'minecraft:diamond',B:'minecraft:nether_star',C:'minecraft:netherite_ingot'})

    event.remove({output: 'minecraft:diamond_pickaxe'})
    event.remove({output: 'minecraft:diamond_sword'})
    event.remove({output: 'minecraft:diamond_axe'})
    event.remove({output: 'minecraft:diamond_shovel'})
    event.remove({output: 'minecraft:diamond_hoe'})

    event.shaped(Item.of('minecraft:diamond_pickaxe'), 
      [' A ','ABA',], 
      {A: 'minecraft:diamond', B: 'minecraft:iron_pickaxe'})

    event.shaped(Item.of('minecraft:diamond_shovel'), 
      [' A ','ABA',], 
      {A: 'minecraft:diamond', B: 'minecraft:iron_shovel'})

    event.shaped(Item.of('minecraft:diamond_hoe'), 
      ['AA','AB',], 
      {A: 'minecraft:diamond', B: 'minecraft:iron_hoe'})

    event.shaped(Item.of('minecraft:diamond_axe'), 
      ['AA','AB',], 
      {A: 'minecraft:diamond', B: 'minecraft:iron_axe'})

    event.shaped(Item.of('minecraft:diamond_sword'), 
      [' A ','ABA', ' A '], 
      {A: 'minecraft:diamond', B: 'minecraft:iron_sword'})

    event.remove({output: 'minecraft:crafting_table'})
    event.shapeless(
      Item.of('minecraft:crafting_table', 1),
      [
        '#minecraft:sand',
        'kubejs:tools',
        '#minecraft:planks',
        'farmersdelight:rope'
      ]
    )
    event.shapeless('kubejs:poor_copper_ingot', '4x gtceu:copper_nugget')
    event.shapeless('kubejs:poor_tin_ingot', '4x gtceu:tin_nugget')
    event.shapeless('kubejs:low_grade_iron_ingot', '4x minecraft:iron_nugget')
    event.shapeless('kubejs:tools', '4x kubejs:low_grade_iron_ingot')
    event.shapeless('kubejs:tools', '4x kubejs:poor_copper_ingot')
    event.shapeless('kubejs:tools', '4x kubejs:poor_tin_ingot')

    event.shapeless(
      Item.of('minecraft:end_portal_frame'),
      [
        'minecraft:crying_obsidian',
        'minecraft:echo_shard',
        'minecraft:powder_snow_bucket',
        'minecraft:phantom_membrane',
        'minecraft:netherite_ingot',
        'minecraft:bee_nest',
        'minecraft:wind_charge',
        'minecraft:sponge',
        '#c:drinks/magic'
      ]
    )

    event.shapeless(Item.of('minecraft:emerald_block'), ['9x minecraft:emerald'])

    
    //
    // WOOD AND AXES
    //

  //Logs + Axes --> Planks
  

  logging('4x minecraft:oak_planks', "#minecraft:oak_logs")
  logging('4x minecraft:spruce_planks', "#minecraft:spruce_logs")
  logging('4x minecraft:birch_planks', "#minecraft:birch_logs")
  logging('4x minecraft:jungle_planks', "#minecraft:jungle_logs")
  logging('4x minecraft:acacia_planks', "#minecraft:acacia_logs")
  logging('4x minecraft:dark_oak_planks', "#minecraft:dark_oak_logs")
  logging('4x minecraft:crimson_planks', "#minecraft:crimson_stems")
  logging('4x minecraft:warped_planks', "#minecraft:warped_stems")
  logging('4x minecraft:mangrove_planks', "#minecraft:mangrove_logs")
  logging('4x minecraft:bamboo_planks', "#minecraft:bamboo_blocks")
  logging('4x minecraft:cherry_planks', "#minecraft:cherry_logs")

  //Planks + Axes --> Slabs

  slabbing('2x minecraft:oak_slab', "minecraft:oak_planks")
  slabbing('2x minecraft:spruce_slab', "minecraft:spruce_planks")
  slabbing('2x minecraft:birch_slab', "minecraft:birch_planks")
  slabbing('2x minecraft:jungle_slab', "minecraft:jungle_planks")
  slabbing('2x minecraft:acacia_slab', "minecraft:acacia_planks")
  slabbing('2x minecraft:dark_oak_slab', "minecraft:dark_oak_planks")
  slabbing('2x minecraft:crimson_slab', "minecraft:crimson_planks")
  slabbing('2x minecraft:warped_slab', "minecraft:warped_planks")
  slabbing('2x minecraft:mangrove_slab', "minecraft:mangrove_planks")
  slabbing('2x minecraft:bamboo_slab', "minecraft:bamboo_planks")
  slabbing('2x minecraft:cherry_slab', "minecraft:cherry_planks")

  //Planks + Axes --> Sticks

  event.shaped(
    Item.of('minecraft:stick', 4),
    [
      'A',
      'B'
    ],
    {
      A: '#minecraft:axes',
      B: '#minecraft:planks'
    }
  ).damageIngredient("#minecraft:axes")
  event.shaped(
    Item.of('minecraft:ladder', 1),
    [
      'A ',
      ' A'
    ],
    {
      A: 'minecraft:stick'
    }
  )

  //
  // NEW ITEM RECIPES
  //

  event.shapeless(
    Item.of('kubejs:bone_needle'),
    [
      '#c:tools/knife',
      'minecraft:bone'
    ]
  ).damageIngredient('#c:tools/knife')
  event.shapeless(
    Item.of('kubejs:bone_needle_with_string'),
    ['kubejs:bone_needle', 'minecraft:string']
  )
 event.remove({output:'pointblank:printer'})
 event.recipes.createMechanicalCrafting(
  'pointblank:printer',
  ['DDDDDD','LSPCLD','LSMCLD','LDDDLD','DDDDDD'], 
  {
    D:'gtceu:double_steel_plate',
    L:'gtceu:long_steel_rod',
    S:'gtceu:sticky_resin',
    P:'create_enchantment_industry:printer',
    M:'gtceu:lv_electric_motor',
    C:'gtceu:basic_electronic_circuit',
  }
 ).id('pointblank_printer_recipe');

  //
  //EXTRA MOD CRAFTING RECIPE TESTS
  //

//  event.recipes.createMechanicalCrafting(
//    'minecraft:netherite_ingot',
//    [' AAA ','ABBBA','ABCBA','ABBBA',' AAA '],
//    {
//      A: 'minecraft:diamond',
//      B: 'minecraft:gold_ingot',
//      C: 'minecraft:netherite_scrap',
//    }
//  ).id("netherite_ingot_low");

//  gregtech.assembler('my_custom_recipe')
//    .inputItems('gtceu:steel_frame')
//    .inputItems('8x gtceu:steel_plate')
//    .outputItems('minecraft:pufferfish')
//    .EUt(32)
//    .duration(100)


event.recipes.create.finalize()
}) //DO NOT PUT ANY RECIPES BEYOND THIS POINT 
