ServerEvents.recipes(event=>{
    let modifiedGuns = {}
    
    let getRecipeJson = (recipeId) => {
        let recipe = event.findRecipes({id: recipeId})
        if(!recipe) return;
        return JSON.parse(recipe[0].json.toString())    
    }

    function gun_modify(r, extra, extracount) {
        //Assume recipe id is the same as result item id 
        let recipeJson = getRecipeJson(r)
        if(!r) return;
        event.remove({ id: r })
        let newingredients = modifiedGuns[r]?.ingredients||recipeJson.ingredients
        // let output = r.originalRecipeResult
        newingredients.push({count: extracount, item: extra})
        let customJson = {
            type: 'pointblank:default',
            ingredients: newingredients,
            result: {item: r}  
        }
        modifiedGuns[r] = customJson
        console.log(modifiedGuns[r])
      }

      gun_modify('pointblank:glock17','gtceu:steel_ingot',5)
      gun_modify('pointblank:glock18','gtceu:steel_ingot',5)
      gun_modify('pointblank:m9','gtceu:steel_ingot',5)
      gun_modify('pointblank:m1911a1','gtceu:steel_ingot',5)
      gun_modify('pointblank:tti_viper','gtceu:steel_ingot',5)
      gun_modify('pointblank:p30l','gtceu:steel_ingot',5)
      gun_modify('pointblank:mk23','gtceu:steel_ingot',5)
      gun_modify('pointblank:deserteagle','gtceu:steel_ingot',5)
      gun_modify('pointblank:rhino','gtceu:steel_ingot',5)
      gun_modify('pointblank:m4a1','gtceu:nan_certificate')
      gun_modify('pointblank:m4a1mod1','gtceu:nan_certificate')
      gun_modify('pointblank:star15','gtceu:nan_certificate')
      gun_modify('pointblank:m4sopmodii','gtceu:nan_certificate')
      gun_modify('pointblank:m16a1','gtceu:nan_certificate')
      gun_modify('pointblank:hk416','gtceu:nan_certificate')
      gun_modify('pointblank:scarl','gtceu:nan_certificate')
      gun_modify('pointblank:xm7','gtceu:nan_certificate')
      gun_modify('pointblank:g36c','gtceu:nan_certificate')
      gun_modify('pointblank:g36k','gtceu:nan_certificate')
      gun_modify('pointblank:aug','gtceu:nan_certificate')
      gun_modify('pointblank:g41','gtceu:nan_certificate')
      gun_modify('pointblank:ak47','gtceu:nan_certificate')
      gun_modify('pointblank:ak74','gtceu:nan_certificate')
      gun_modify('pointblank:ak12','gtceu:nan_certificate')
      gun_modify('pointblank:an94','gtceu:nan_certificate')
      gun_modify('pointblank:ar57','gtceu:nan_certificate')
      gun_modify('pointblank:xm29','gtceu:nan_certificate')
      gun_modify('pointblank:mp5','gtceu:nan_certificate')
      gun_modify('pointblank:mp7','gtceu:nan_certificate')
      gun_modify('pointblank:ro635','gtceu:nan_certificate')
      gun_modify('pointblank:ump45','gtceu:nan_certificate')
      gun_modify('pointblank:vector','gtceu:nan_certificate')
      gun_modify('pointblank:p90','gtceu:nan_certificate')
      gun_modify('pointblank:m950','gtceu:nan_certificate')
      gun_modify('pointblank:tmp','gtceu:nan_certificate')
      gun_modify('pointblank:sl8','gtceu:nan_certificate')
      gun_modify('pointblank:mk14ebr','gtceu:nan_certificate')
      gun_modify('pointblank:uar10','gtceu:nan_certificate')
      gun_modify('pointblank:g3','gtceu:nan_certificate')
      gun_modify('pointblank:wa2000','gtceu:nan_certificate')
      gun_modify('pointblank:xm3','gtceu:nan_certificate')
      gun_modify('pointblank:c14','gtceu:nan_certificate')
      gun_modify('pointblank:l96a1','gtceu:nan_certificate')
      gun_modify('pointblank:ballista','gtceu:nan_certificate')
      gun_modify('pointblank:gm6lynx','gtceu:nan_certificate')
      gun_modify('pointblank:m590','gtceu:nan_certificate')
      gun_modify('pointblank:m870','gtceu:nan_certificate')
      gun_modify('pointblank:spas12','gtceu:nan_certificate')
      gun_modify('pointblank:m1014','gtceu:nan_certificate')
      gun_modify('pointblank:aa12','gtceu:nan_certificate')
      gun_modify('pointblank:citoricxs','gtceu:nan_certificate')
      gun_modify('pointblank:hs12','gtceu:nan_certificate')
      gun_modify('pointblank:aughbar','gtceu:nan_certificate')
      gun_modify('pointblank:lamg','gtceu:nan_certificate')
      gun_modify('pointblank:mk48','gtceu:nan_certificate')
      gun_modify('pointblank:m249','gtceu:nan_certificate')
      gun_modify('pointblank:m32mgl','gtceu:nan_certificate')
      gun_modify('pointblank:smaw','gtceu:nan_certificate')
      gun_modify('pointblank:at4','gtceu:nan_certificate')
      gun_modify('pointblank:javelin','gtceu:nan_certificate')
      gun_modify('pointblank:m134minigun','gtceu:nan_certificate')

      Object.keys(modifiedGuns).forEach(key => event.custom(modifiedGuns[key]))
})