StartupEvents.registry('item', event => {
    event.create('tools').displayName('Crafting Tools')
    event.create('low_grade_iron_ingot').displayName('Low Grade Iron Ingot')
    event.create('poor_tin_ingot').displayName('Poor Tin Ingot')
    event.create('poor_copper_ingot').displayName('Poor Copper Ingot')
    event.create('bone_needle').displayName('Bone Needle')
    event.create('bone_needle_with_string').displayName('Needle & String')
    event.create('plated_gold_ingot').displayName('Plated Gold')
})