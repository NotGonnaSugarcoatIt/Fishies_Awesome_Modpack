ClientEvents.lang("en_us", event => {
    event.renameItem('minecraft:iron_ingot', 'High Grade Iron Ingot')
    event.renameBlock('minecraft:iron_block', "Block of High Grade Iron")
    event.renameItem('cataclysm:black_steel_ingot', 'Dark Steel Ingot')
})

RecipeViewerEvents.removeEntries('item', event => {
    event.remove('minecraft:beetroot_seeds')
})